public class Main {
    public static void main(String[] args) {
        double d = (double) 1/3;
        System.out.println(d);
    }
}
